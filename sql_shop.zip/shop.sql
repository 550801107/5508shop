/*
SQLyog Job Agent v12.09 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.53 : Database - tpshop
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`tpshop` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `tpshop`;

/*Table structure for table `yx_address` */

DROP TABLE IF EXISTS `yx_address`;

CREATE TABLE `yx_address` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(30) NOT NULL COMMENT '用户名',
  `phone` varchar(11) NOT NULL COMMENT '手机号',
  `postcode` char(10) NOT NULL COMMENT '邮编',
  `addr` varchar(50) NOT NULL COMMENT '详细地址',
  `time` int(10) NOT NULL COMMENT '发货时间',
  PRIMARY KEY (`id`),
  KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户收货信息表';

/*Data for the table `yx_address` */

/*Table structure for table `yx_admin_user` */

DROP TABLE IF EXISTS `yx_admin_user`;

CREATE TABLE `yx_admin_user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `password` varchar(50) NOT NULL DEFAULT '' COMMENT '管理员密码',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态 1 启用 0 禁用',
  `create_time` varchar(50) DEFAULT NULL COMMENT '创建时间',
  `last_login_time` varchar(50) DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(20) DEFAULT NULL COMMENT '最后登录IP',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='管理员表';

/*Data for the table `yx_admin_user` */

insert  into `yx_admin_user` values (1,'admin','8d481b131be8e0e9e1890daf2d29aa3b',1,'1494317546','2017-11-25 11:02:10','127.0.0.1'),(3,'demo','a24dfc8e919798d7f7b857775175527c',1,NULL,'2017-11-16 15:54:06','127.0.0.1');

/*Table structure for table `yx_article` */

DROP TABLE IF EXISTS `yx_article`;

CREATE TABLE `yx_article` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `keywords` varchar(255) DEFAULT NULL COMMENT '关键字',
  `title` varchar(255) DEFAULT NULL COMMENT '文章标题',
  `introduction` varchar(255) DEFAULT NULL COMMENT '文章简介',
  `cid` int(10) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL COMMENT '坐着ID',
  `reading` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `publish_time` varchar(50) DEFAULT NULL,
  `sort` int(5) NOT NULL DEFAULT '255',
  `create_time` varchar(50) DEFAULT NULL,
  `content` longtext COMMENT '文章内容',
  `photo` varchar(255) DEFAULT NULL COMMENT '图集',
  `thumb` varchar(255) DEFAULT NULL COMMENT '文章封面',
  `is_top` int(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `comments` int(10) NOT NULL DEFAULT '0' COMMENT '评论数',
  `is_hot` int(1) NOT NULL DEFAULT '0' COMMENT '是否加精',
  `offer` int(10) unsigned NOT NULL DEFAULT '10' COMMENT '悬赏',
  `author_id` int(10) DEFAULT NULL COMMENT '作者ID',
  `is_end` int(1) NOT NULL DEFAULT '0' COMMENT '是否结贴',
  `attar` varchar(255) DEFAULT NULL COMMENT '附件',
  `baiduapi` int(1) unsigned zerofill NOT NULL DEFAULT '0' COMMENT '是否提交Baidu',
  `identity_id` int(1) NOT NULL DEFAULT '0' COMMENT '阅读角色ID',
  `is_download` int(1) unsigned zerofill DEFAULT '0' COMMENT '是否推荐下载',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `yx_article` */

insert  into `yx_article` values (1,'ITKEE社区介绍','ITKEE社区介绍','',1,'SuperMan',0,1,'2017-07-20 16:02:50',0,'1500538109','<p><span style=\"font-size: 16px;\">ITKEE社区功能简介：</span></p><p><span style=\"font-size: 16px;\">采用thinkphp5全新制作</span></p><p><span style=\"font-size: 16px;\">秉承：<span style=\"color: rgb(255, 0, 0); font-size: 16px;\"><strong>极速 清新 精简&nbsp;</strong></span></span></p><p><span style=\"font-size: 16px;\">理念打造</span></p><p><br/></p><p><span style=\"font-size: 16px;\">身处在前端社区的繁荣之下，我们都在有意或无意地追逐,<span style=\"font-family:;\">返璞归真</span></span></p><p><span style=\"font-size: 16px;\"><span style=\"font-family:;\"><br/></span></span></p><p><span style=\"font-size: 16px;\"><span style=\"font-family:;\"><span style=\"font-family:;\">如果您在使用系统的过程中获得了一定的的收益，请不要吝啬您的言语，可以在社区写一篇鼓励我们的话，我们会更努力！ <a href=\"http://www.itkee.cn/\" target=\"_blank\">立即赞扬</a></span></span></span></p><p><br/></p><p style=\"padding: 0px; font-family:; margin-top: 0px; margin-bottom: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">[ITKEE社区] PHP/前端/交流，互联网技术交流，资源分享，我们一直在努力，欢迎加入！</p><p style=\"padding: 0px; font-family:; margin-top: 0px; margin-bottom: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\"><br/></p><p style=\"padding: 0px; font-family:; margin-top: 0px; margin-bottom: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">使用过程中如果遇到问题，请在<a href=\"http://www.itkee.cn/topic.html\" target=\"_blank\">社区发布反馈</a></p><p style=\"padding: 0px; font-family:; margin-top: 0px; margin-bottom: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\"><br/></p><p style=\"padding: 0px; font-family:; margin-top: 0px; margin-bottom: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\"><br/></p><p style=\"padding: 0px; font-family:; margin-top: 0px; margin-bottom: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\"><a style=\"margin: 0px; padding: 0px; color: rgb(0, 176, 80); text-decoration: underline;\" href=\"https://jq.qq.com/?_wv=1027&k=4AEFdBX\" target=\"_blank\"><span style=\"color: rgb(0, 176, 80);\">点击加入</span></a><span style=\"color: rgb(0, 176, 80);\">官方交流群</span></p><p><br/></p>','a:2:{i:0;s:52:\"/public/uploads/images/20170801/1501558772782878.jpg\";i:1;s:52:\"/public/uploads/images/20170801/1501558772371565.jpg\";}','',0,0,1,0,1,0,'',0,0,1),(2,'23','23','',1,'demo',0,1,'2017-08-01 16:19:50',0,'1501575626','',NULL,'/uploads/20171122/f9e91d927d8954f6d5f54c0fd55673ac.jpg',1,0,0,0,3,0,'',0,0,0);

/*Table structure for table `yx_auth_group` */

DROP TABLE IF EXISTS `yx_auth_group`;

CREATE TABLE `yx_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` varchar(255) NOT NULL COMMENT '权限规则ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='权限组表';

/*Data for the table `yx_auth_group` */

insert  into `yx_auth_group` values (1,'超级管理组',1,'5,6,7,8,9,10,11,81,12,39,40,41,42,43,82,14,13,20,21,22,23,24,92,15,25,26,27,28,29,30,83,54,57,68,69,70,71,72,85,84,55,58,59,60,61,62,56,63,64,65,66,67,77,16,17,44,45,46,47,48,18,49,50,51,52,53,19,31,32,33,34,35,36,37,86,79,80,78,1,2,3,73,74,87,88,89,90,91'),(2,'管理员组',1,'5,6,81,12,82,14,13,92,15,30,83,25,26,27,28,113,54,57,85,77,80,16,17,44,45,18,49,100,107,108,19,31,36,37,86,32,33,34,35,94,95,101,78,87,88,89,90,91,93,96,97'),(3,'对外演示权限组',1,'5,6,81,12,82,14,13,92,15,83,98,99,54,57,85,77,79,80,78,1,2,87,88');

/*Table structure for table `yx_auth_group_access` */

DROP TABLE IF EXISTS `yx_auth_group_access`;

CREATE TABLE `yx_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='权限组规则表';

/*Data for the table `yx_auth_group_access` */

insert  into `yx_auth_group_access` values (1,1),(3,2),(3,3),(5,1);

/*Table structure for table `yx_auth_rule` */

DROP TABLE IF EXISTS `yx_auth_rule`;

CREATE TABLE `yx_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL COMMENT '规则名称',
  `title` varchar(20) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `pid` smallint(5) unsigned NOT NULL COMMENT '父级ID',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `sort` tinyint(4) unsigned NOT NULL COMMENT '排序',
  `condition` char(100) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=119 DEFAULT CHARSET=utf8 COMMENT='规则表';

/*Data for the table `yx_auth_rule` */

insert  into `yx_auth_rule` values (1,'admin/index/config','系统配置',1,1,77,'fa fa-gears',0,''),(2,'admin/System/siteConfig','站点配置',1,1,1,'',0,''),(3,'admin/System/updateSiteConfig','更新配置',1,0,1,'',0,''),(5,'admin/Menu/default','菜单',1,0,0,'fa fa-linkedin-square',254,''),(6,'admin/Menu','后台菜单',1,1,5,'fa fa-star',0,''),(7,'admin/Menu/add','添加菜单',1,1,6,'',1,''),(8,'admin/Menu/save','保存菜单',1,0,6,'',0,''),(9,'admin/Menu/edit','编辑菜单',1,0,6,'',0,''),(10,'admin/Menu/update','更新菜单',1,0,6,'',0,''),(11,'admin/Menu/delete','删除菜单',1,0,6,'',0,''),(12,'admin/Nav/index','导航管理',1,1,5,'',0,''),(13,'admin/Category/index','栏目管理',1,1,14,'fa fa-sitemap',0,''),(14,'admin/Content/default','内容',1,0,0,'fa fa-file-text',250,''),(15,'admin/Article/index','文章管理',1,1,14,'',10,''),(16,'admin/User/default','用户管理',1,1,77,'fa fa-users',0,''),(17,'admin/User/index','普通用户',1,1,16,'',0,''),(18,'admin/Admin_user/index','管理员',1,1,16,'',0,''),(19,'admin/Auth_group/index','权限组',1,1,77,'',0,''),(20,'admin/Category/add','添加栏目',1,1,13,'',0,''),(21,'admin/Category/save','保存栏目',1,0,13,'',0,''),(22,'admin/Category/edit','编辑栏目',1,0,13,'',0,''),(23,'admin/Category/update','更新栏目',1,0,13,'',0,''),(24,'admin/Category/delete','删除栏目',1,0,13,'',0,''),(25,'admin/Article/add','添加文章',1,1,83,'',0,''),(26,'admin/Article/save','保存文章',1,0,83,'',0,''),(27,'admin/Article/edit','编辑文章',1,0,83,'',0,''),(28,'admin/Article/update','更新文章',1,0,83,'',0,''),(29,'admin/Article/delete','删除文章',1,0,83,'',0,''),(30,'admin/Article/toggle','文章审核',1,0,15,'',0,''),(31,'admin/Auth_group/add','添加权限组',1,1,19,'',0,''),(32,'admin/AuthGroup/save','保存权限组',1,0,86,'',0,''),(33,'admin/AuthGroup/edit','编辑权限组',1,0,86,'',0,''),(34,'admin/AuthGroup/update','更新权限组',1,0,86,'',0,''),(35,'admin/AuthGroup/delete','删除权限组',1,0,86,'',0,''),(36,'admin/AuthGroup/auth','授权',1,0,19,'',0,''),(37,'admin/AuthGroup/updateAuthGroupRule','更新权限组规则',1,0,36,'',0,''),(39,'admin/Nav/add','添加导航',1,1,12,'',0,''),(40,'admin/Nav/save','保存导航',1,0,12,'',0,''),(41,'admin/Nav/edit','编辑导航',1,0,12,'',0,''),(42,'admin/Nav/update','更新导航',1,0,12,'',0,''),(43,'admin/Nav/delete','删除导航',1,0,12,'',0,''),(44,'admin/User/add','添加用户',1,1,17,'',0,''),(45,'admin/User/save','保存用户',1,0,17,'',0,''),(46,'admin/User/edit','编辑用户',1,0,17,'',0,''),(47,'admin/User/update','更新用户',1,0,17,'',0,''),(48,'admin/User/delete','删除用户',1,0,17,'',0,''),(49,'admin/AdminUser/add','添加管理员',1,1,18,'',0,''),(50,'admin/AdminUser/save','保存管理员',1,0,18,'',0,''),(51,'admin/AdminUser/edit','编辑管理员',1,0,18,'',0,''),(52,'admin/AdminUser/update','更新管理员',1,0,18,'',0,''),(53,'admin/AdminUser/delete','删除管理员',1,0,18,'',0,''),(54,'admin/Slide/default','扩展',1,1,0,'fa fa-wrench',0,''),(55,'admin/Slide_category/index','轮播分类',1,1,84,'',0,''),(56,'admin/Slide/index','轮播图管理',1,1,84,'',0,''),(57,'admin/Link/index','友情链接',1,1,54,'fa fa-link',0,''),(58,'admin/SlideCategory/add','添加分类',1,1,55,'',0,''),(59,'admin/SlideCategory/save','保存分类',1,0,55,'',0,''),(60,'admin/SlideCategory/edit','编辑分类',1,0,55,'',0,''),(61,'admin/SlideCategory/update','更新分类',1,0,55,'',0,''),(62,'admin/SlideCategory/delete','删除分类',1,0,55,'',0,''),(63,'admin/Slide/add','添加轮播',1,1,56,'',0,''),(64,'admin/Slide/save','保存轮播',1,1,56,'',0,''),(65,'admin/Slide/edit','编辑轮播',1,0,56,'',0,''),(66,'admin/Slide/update','更新轮播',1,0,56,'',0,''),(67,'admin/Slide/delete','删除轮播',1,0,56,'',0,''),(68,'admin/Link/add','添加链接',1,1,57,'',0,''),(69,'admin/Link/save','保存链接',1,0,57,'',0,''),(70,'admin/Link/edit','编辑链接',1,0,57,'',0,''),(71,'admin/Link/update','更新链接',1,0,57,'',0,''),(72,'admin/Link/delete','删除链接',1,0,57,'',0,''),(73,'admin/Change_password/index','修改密码',1,1,1,'',0,''),(74,'admin/ChangePassword/updatePassword','更新密码',1,0,1,'',0,''),(77,'admin/index/index','平台',1,1,0,'',255,''),(81,'admin/Menu/index','菜单管理',1,1,6,'',10,''),(82,'admin/nav/index','导航列表',1,1,12,'',1,''),(80,'admin/index/webSite','站点动态',1,1,1,'',9,''),(83,'admin/Article/index','文章列表',1,1,15,'',10,''),(84,'default','轮播管理',1,1,54,'',0,''),(85,'admin/link/index','友链列表',1,1,57,'',10,''),(86,'admin/Auth_group/index','权限列表',1,1,19,'',10,''),(92,'admin/Category/index','栏目列表',1,1,13,'fa fa-wrench',10,''),(106,'Admin/Navcat/index','导航分类',1,1,12,'',0,''),(113,'admin/article/topToggle','加精/置顶/推荐下载',1,0,83,'',0,'');

/*Table structure for table `yx_brand` */

DROP TABLE IF EXISTS `yx_brand`;

CREATE TABLE `yx_brand` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL COMMENT '品牌名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='品牌表';

/*Data for the table `yx_brand` */

/*Table structure for table `yx_cart` */

DROP TABLE IF EXISTS `yx_cart`;

CREATE TABLE `yx_cart` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT '自增',
  `user_id` int(5) NOT NULL COMMENT '买家id',
  `goods_id` int(5) DEFAULT NULL COMMENT '商品的id',
  `price_count` int(11) DEFAULT NULL COMMENT '金额小计',
  `mprice_count` int(11) DEFAULT NULL COMMENT '市场价格小计',
  `sale_num` int(11) DEFAULT NULL COMMENT '购买数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='购物车';

/*Data for the table `yx_cart` */

/*Table structure for table `yx_category` */

DROP TABLE IF EXISTS `yx_category`;

CREATE TABLE `yx_category` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '栏目名称',
  `parent_id` int(4) unsigned DEFAULT NULL COMMENT '栏目id 0代表顶级栏目',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='栏目表';

/*Data for the table `yx_category` */

/*Table structure for table `yx_college` */

DROP TABLE IF EXISTS `yx_college`;

CREATE TABLE `yx_college` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(5) unsigned NOT NULL COMMENT '用户id',
  `goods_id` int(5) unsigned NOT NULL COMMENT '商品id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='收藏表';

/*Data for the table `yx_college` */

/*Table structure for table `yx_link` */

DROP TABLE IF EXISTS `yx_link`;

CREATE TABLE `yx_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '链接名称',
  `link` varchar(255) DEFAULT '' COMMENT '链接地址',
  `image` varchar(255) DEFAULT '' COMMENT '链接图片',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态 1 显示  2 隐藏',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='友情链接表';

/*Data for the table `yx_link` */

insert  into `yx_link` values (2,'SuperMan博客','http://superman.itkee.cn','',0,20);

/*Table structure for table `yx_nav` */

DROP TABLE IF EXISTS `yx_nav`;

CREATE TABLE `yx_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL COMMENT '父ID',
  `name` varchar(20) NOT NULL COMMENT '导航名称',
  `alias` varchar(20) DEFAULT '' COMMENT '导航别称',
  `link` varchar(255) DEFAULT '' COMMENT '导航链接',
  `icon` varchar(255) DEFAULT '' COMMENT '导航图标',
  `target` varchar(10) DEFAULT '' COMMENT '打开方式',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态  0 隐藏  1 显示',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `nav_cid` int(10) DEFAULT NULL COMMENT '分类ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='导航表';

/*Data for the table `yx_nav` */

/*Table structure for table `yx_nav_cat` */

DROP TABLE IF EXISTS `yx_nav_cat`;

CREATE TABLE `yx_nav_cat` (
  `navcid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '导航分类名',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '是否为主菜单，1是，0不是',
  `remark` text COMMENT '备注',
  PRIMARY KEY (`navcid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='前台导航分类表';

/*Data for the table `yx_nav_cat` */

insert  into `yx_nav_cat` values (1,'主导航',1,'头部主导航'),(2,'底部纵向导航',1,'站点公共底部导航'),(3,'底部横向导航',1,'底部横向导航');

/*Table structure for table `yx_order` */

DROP TABLE IF EXISTS `yx_order`;

CREATE TABLE `yx_order` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(30) NOT NULL COMMENT '订单号',
  `user_id` int(5) NOT NULL COMMENT '用户id',
  `time` int(10) NOT NULL COMMENT '下单时间',
  `money` decimal(10,2) NOT NULL COMMENT '订单金额',
  `name` varchar(30) NOT NULL COMMENT '收货人姓名',
  `phone` varchar(11) NOT NULL COMMENT '收货人手机号',
  `postcode` varchar(10) NOT NULL COMMENT '收货人邮编',
  `addr` varchar(40) NOT NULL COMMENT '收货人详细地址',
  `order_stat` varchar(10) NOT NULL COMMENT '订单状态',
  `order_exp` varchar(10) NOT NULL COMMENT '送货方式',
  `order_mon` varchar(10) NOT NULL COMMENT '支付方式',
  `order_mes` text NOT NULL COMMENT '订单留言',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单表';

/*Data for the table `yx_order` */

/*Table structure for table `yx_shopattr` */

DROP TABLE IF EXISTS `yx_shopattr`;

CREATE TABLE `yx_shopattr` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(2) unsigned NOT NULL COMMENT '类别id',
  `name` varchar(30) NOT NULL COMMENT '商品属性名称',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商品属性表';

/*Data for the table `yx_shopattr` */

/*Table structure for table `yx_shopcategory` */

DROP TABLE IF EXISTS `yx_shopcategory`;

CREATE TABLE `yx_shopcategory` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` tinyint(3) NOT NULL COMMENT '父id,0代表顶级id',
  `name` varchar(30) NOT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商品分类表';

/*Data for the table `yx_shopcategory` */

/*Table structure for table `yx_shopgoods` */

DROP TABLE IF EXISTS `yx_shopgoods`;

CREATE TABLE `yx_shopgoods` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(2) unsigned NOT NULL COMMENT '商品属性id',
  `brand_id` int(2) unsigned DEFAULT NULL COMMENT '品牌id',
  `name` varchar(30) NOT NULL COMMENT '商品名称',
  `number` int(5) unsigned DEFAULT NULL COMMENT '库存量',
  `mprice` decimal(10,2) DEFAULT NULL COMMENT '市场价格',
  `price` decimal(10,2) DEFAULT NULL COMMENT '店面价格',
  `brief` text NOT NULL COMMENT '商品详细描述',
  `add_time` int(10) NOT NULL COMMENT '上架时间',
  `up_time` int(10) NOT NULL COMMENT '更新时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除 默认0  1代表删除',
  `img` varchar(80) NOT NULL COMMENT '封面图片',
  `thumb` varchar(80) NOT NULL COMMENT '缩略图',
  `is_tag` tinyint(1) NOT NULL COMMENT '标记 1代表精品 2代表热品 3代表热销 4代表低价促销',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否上架, 默认1  代表上架 0代表下架',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `brand_id` (`brand_id`),
  KEY `is_tag` (`is_tag`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商品详情表';

/*Data for the table `yx_shopgoods` */

/*Table structure for table `yx_shoptype` */

DROP TABLE IF EXISTS `yx_shoptype`;

CREATE TABLE `yx_shoptype` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(2) unsigned NOT NULL COMMENT '分类id',
  `name` varchar(30) NOT NULL COMMENT '商品类型名称',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商品类别表';

/*Data for the table `yx_shoptype` */

/*Table structure for table `yx_slide` */

DROP TABLE IF EXISTS `yx_slide`;

CREATE TABLE `yx_slide` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL COMMENT '分类ID',
  `name` varchar(50) NOT NULL COMMENT '轮播图名称',
  `description` varchar(255) DEFAULT '' COMMENT '说明',
  `link` varchar(255) DEFAULT '' COMMENT '链接',
  `target` varchar(10) DEFAULT '' COMMENT '打开方式',
  `image` varchar(255) DEFAULT '' COMMENT '轮播图片',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态  1 显示  0  隐藏',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='轮播图表';

/*Data for the table `yx_slide` */

insert  into `yx_slide` values (3,2,'开源社区下载','','http://www.itkee.cn/index/topic/detail/id/51.html','_self','/uploads/20170608/40138fc1bb4fc2a6cb74440d14307d9b.png',1,10),(2,2,'社区介绍','','http://www.itkee.cn/index/topic/detail/id/131.html','_self','/uploads/20170621/12ea85a96caaeefa7a5887d7009c004e.gif',1,50),(4,2,'ShopNC源码下载','','http://www.itkee.cn/index/topic/detail/id/144.html','_self','/uploads/20170610/ccbf6dab14d6fb6f1222b58aa377347f.png',1,5),(5,2,'itkee_cmf下载','itkee_cmf下载','http://www.itkee.cn/topic-info-168.html','_blank','/uploads/20170618/8b7690b391f7bcce9af6d28ead8ca688.png',1,50),(6,1,'首页轮播','哈哈哈','','_self','/uploads/20170718/4438923691bbe1063e45a249e06c9315.png',1,0);

/*Table structure for table `yx_slide_category` */

DROP TABLE IF EXISTS `yx_slide_category`;

CREATE TABLE `yx_slide_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '轮播图分类',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='轮播图分类表';

/*Data for the table `yx_slide_category` */

insert  into `yx_slide_category` values (1,'首页轮播'),(2,'右侧轮播');

/*Table structure for table `yx_system` */

DROP TABLE IF EXISTS `yx_system`;

CREATE TABLE `yx_system` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '配置项名称',
  `value` text NOT NULL COMMENT '配置项值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

/*Data for the table `yx_system` */

insert  into `yx_system` values (1,'site_config','a:7:{s:10:\"site_title\";s:14:\"ITKEE.CN社区\";s:9:\"seo_title\";s:36:\"ITKEE社区-极速，清新，精简\";s:11:\"seo_keyword\";s:36:\"ITKEE社区-极速，清新，精简\";s:15:\"seo_description\";s:426:\"ITKEE.CN是以技术交流为中心开发的社区论坛，由几个志同道合的程序员一起维护组建的互联网技术工作室,曾为上百客户排忧解难，目前主要PHP技术交流，技术服务，前端开发，UI社区等业务为主线运营,社区及工作室主要定位于：互联网技术交流，互联网资源分享，网站开发，电商网站技术支持，整站开发，二次开发等服务\";s:14:\"site_copyright\";s:76:\"Copyright © 2016-2017 ITKEE.CN. All Rights Reserved. ITKEE.CN 版权所有\";s:8:\"site_icp\";s:0:\"\";s:11:\"site_tongji\";s:109:\"<script src=\"https://s19.cnzz.com/z_stat.php?id=1262986736&web_id=1262986736\" language=\"JavaScript\"></script>\";}'),(2,'email_config',''),(3,'system_config','a:2:{s:9:\"app_debug\";s:4:\"true\";s:9:\"app_trace\";s:5:\"false\";}'),(4,'qq_config','');

/*Table structure for table `yx_user` */

DROP TABLE IF EXISTS `yx_user`;

CREATE TABLE `yx_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(50) NOT NULL COMMENT '密码',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机',
  `email` varchar(50) DEFAULT '' COMMENT '邮箱',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '用户状态  1 正常  2 禁止',
  `create_time` varchar(50) DEFAULT NULL COMMENT '创建时间',
  `last_login_time` varchar(50) DEFAULT NULL COMMENT '最后登陆时间',
  `last_login_ip` varchar(50) DEFAULT '' COMMENT '最后登录IP',
  `avatar` varchar(100) DEFAULT NULL COMMENT '用户头像',
  `intro` varchar(255) DEFAULT NULL COMMENT '个人介绍',
  `points` int(10) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `qq_openid` varchar(100) DEFAULT NULL COMMENT 'QQ_openid',
  `sex` varchar(10) NOT NULL DEFAULT '保密' COMMENT '性别',
  `province` varchar(50) DEFAULT NULL COMMENT '用户省份',
  `city` varchar(50) DEFAULT NULL,
  `year` varchar(10) DEFAULT NULL,
  `truename` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `qq` varchar(50) DEFAULT NULL,
  `identity_id` int(10) DEFAULT '0' COMMENT '用户身份',
  `coin` int(11) NOT NULL DEFAULT '0' COMMENT '用户金币',
  PRIMARY KEY (`id`),
  KEY `username` (`username`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='用户表';

/*Data for the table `yx_user` */

insert  into `yx_user` values (2,'ssd','8d481b131be8e0e9e1890daf2d29aa3b','','',1,'1501295291',NULL,'',NULL,NULL,0,NULL,'保密',NULL,NULL,NULL,NULL,NULL,0,0),(3,'sdsda','8d481b131be8e0e9e1890daf2d29aa3b','','',1,'1501556442',NULL,'',NULL,NULL,0,NULL,'保密',NULL,NULL,NULL,NULL,NULL,0,0),(4,'demo','a24dfc8e919798d7f7b857775175527c','','',1,'1501572469',NULL,'',NULL,NULL,0,NULL,'保密',NULL,NULL,NULL,NULL,NULL,0,0),(5,'234234','36837243869b6ba3f260c625ec3fc919','','',1,'1501585751',NULL,'',NULL,NULL,0,NULL,'保密',NULL,NULL,NULL,NULL,NULL,0,0),(6,'qw','1f4f8fda92a89ff9b3c1d7933ff32ff6','asd','asd',1,'1501662847',NULL,'',NULL,NULL,0,NULL,'保密',NULL,NULL,NULL,NULL,NULL,0,0),(7,'234','d999fff35086696499b0f8f13723b929','234','234',1,'1501671512',NULL,'',NULL,NULL,0,NULL,'保密',NULL,NULL,NULL,NULL,NULL,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
